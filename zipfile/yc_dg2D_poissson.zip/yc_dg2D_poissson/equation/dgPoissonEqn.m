function [sysErr,sysTime] = dgPoissonEqn(pde,option,varargin)
%
%   hdgDiffusionOption solve the Stokes equation by HDG methods
%
%	hdgDiffusionOption computes approximations to the Diffusion equation on a
%	sequence of meshes obtained by uniform refinement of a input mesh.
% 
%
%	YcZhang 12/8/2017
%
%   Last modified 12/8/2017
%

%% Default setting of mesh and pde data
if ~exist('option','var') 
    option = []; 
end
if ~exist('pde','var')
    pde = poissonData(0,5); % default data
end


%% Parameters
option = dgOption(option);
maxIt = option.maxIt;


%% Initialize err
uh_L2_error = zeros(maxIt,1); uh_H1_error = zeros(maxIt,1);
uhL2rate = zeros(maxIt,1); uhH1rate = zeros(maxIt,1);
h = zeros(maxIt,1);
% Nnodes = zeros(maxIt,1);
% Ndof = zeros(maxIt,1);

%>>>>>>>>>  creat log file >>>>>>>>
date = datestr(now,31); 
    %> capture the now time, 31 stands for the scheme: 2000-03-01 15:45:17
logFilename=['/home/yczhang/YCCODES/yc_dg2D/logs/dgPoisson_', ...
    date,'_log.txt'];
diary(logFilename);
diary on; % begin diary
%<<<<<<<<<<<<<<<<<<<<<<<<<<

disp('********************  dg Poisson  ********************')
disp('------------------------------------------------------')
disp('DG parameters: ')
disp(['basesType_trial: ', option.basesType_trial])
disp(['basesType_test: ', option.basesType_test])
disp(['penalty pars: p_epsilon: ', num2str(option.p_epsilon)])
disp(['penalty pars: p_sigma: ', num2str(option.p_sigma)])
disp(['penalty pars: p_beta: ', num2str(option.p_beta)])
disp(['maxIt: ', num2str(maxIt)])

%% DG methods
disp('------------------------------------------------------')
disp('Solving dgPoisson: ')
disp('------------------------------------------------------')
format long e
for n = 1:maxIt
    n_str = num2str(n);
    mesh_name = ['Polygon_',n_str];
    load(mesh_name);
    
    disp('')
    n_th_cycle = ['the ',n_str,'-th cycle(i.e. the ', n_str, '-th mesh)'];
    disp(n_th_cycle)
    
    node = vertices;
    elem = elements;
    meshInfo = polyMeshAuxStructure(node, elem);
%     plotPolyMsh(meshInfo)

    solve_t0 = cputime;
    [Uh, sysInfo]= dgPoissonSolve(meshInfo,pde,option);
    sysInfo.SoverTime = cputime - solve_t0;
    disp(['the solve-func time: ',num2str(sysInfo.SoverTime)])
    
    % compute the err
    err_t0 = cputime;
    [uh_L2_error(n), uh_H1_error(n)] = dgL2H1Error(pde.u,pde.ux,pde.uy,Uh,meshInfo,sysInfo.Gaussformulas{1},option.basesType_trial);
    sysInfo.ErrTime = cputime - err_t0;
    disp(['compute Err time: ',num2str(sysInfo.ErrTime)])
    
%     h(n) = sum(meshInfo.diameters)/length(elem);
    h(n) = sum(dia)/length(elem);

    disp('------------------------------------------------------')
end % for n
disp('------------------------------------------------------')
%%
uhL2rate(2:maxIt) = log(uh_L2_error(1:maxIt-1)./uh_L2_error(2:maxIt)) ...
    ./log(h(1:maxIt-1)./h(2:maxIt));
uhH1rate(2:maxIt) =  log(uh_H1_error(1:maxIt-1)./uh_H1_error(2:maxIt)) ...
    ./log(h(1:maxIt-1)./h(2:maxIt));

disp('Table: Error')
colname = {'h  ', '   ||u-U_h||_0 ','   ||u-U_h||_1'};
disptable(colname, h,'%0.2e', uh_L2_error,'%0.5e', ...
    uh_H1_error,'%0.5e');

disp('Table: Error rate')
colname = {'h', '   UhL2rate', '   UhH1rate'};
disptable(colname, h,'%0.2e', uhL2rate,'%0.4f', ...
    uhH1rate,'%0.4f');
disp('------------------------------------------------------')

%>>>>>>>>>  close the diary >>>>>>
diary off; % close the diary
%<<<<<<<<<<<<<<<<<<<<<<<<<<
end % function dgPoissonEqn