function syms_compute_local_basis
clc
clear

syms x_b xE_b y_b yE_b hE
x = (x_b-xE_b)/hE;
y = (y_b-yE_b)/hE;

Pb1 = [1, x, y]
Pb1_x = diff(Pb1,x_b)
Pb1_y = diff(Pb1,y_b)


Pb2 = [1 x y x.^2 x.*y y.^2]
Pb2_x = diff(Pb2,x_b)
Pb2_y = diff(Pb2,y_b)

Pb3 = [1  x  y  x.^2  x.*y  y.^2   x.^3    x.^2.*y  x.*y.^2  y.^3]
Pb3_x = diff(Pb3,x_b)
Pb3_y = diff(Pb3,y_b)

Pb4 = [1  x  y  x.^2  x.*y  y.^2   x.^3    x.^2.*y  x.*y.^2  y.^3   x.^4     x.^3.*y    x.^2.*y.^2   x.*y.^3 y.^4]
Pb4_x = diff(Pb4,x_b)
Pb4_y = diff(Pb4,y_b)

end % function