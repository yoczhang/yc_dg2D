function syms_derivate()
syms X1 X2 x y
u = @(x,y) exp(-x-y^2);
ux=diff(u,x)
uy=diff(u,y)

uxx = diff(ux,x)
uyy = diff(uy,y)

end % function