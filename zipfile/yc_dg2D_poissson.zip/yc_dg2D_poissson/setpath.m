%% Set path to FEM  
%
% Add all subdirectories under pathstr to search path.
%
%
clear 
close all
clc
addpath(genpath(pwd),'-begin');
% savepath;
