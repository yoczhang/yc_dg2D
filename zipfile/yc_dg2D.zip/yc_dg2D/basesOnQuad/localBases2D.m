function [Pb, Pbx, Pby] = localBases2D(xT, yT, hT, x, y, k)
%
%   In this function we compute the values of 2D local bases at physical local Gauss-Points.
%
%   We let Nbases denote the number of bases, Npoints denote the number of
%   Gauss-Points.
%
%   input:
%       x, the x-coordinates of physical local Gauss-Points, size: 
%                               a row vector, [Npoints x 1].
%       y, the y-coordinates of physical local Gauss-Points, size: 
%                               a row vector, [Npoints x 1].
%       k, the degree of the polynomial, size: a scalar.
%
%   output:
%       Pb, the value of bases at given coordinates, size: 
%                               a matrix, [Npoints x Nbases].
%       Pbx, the derivative to x of the bases, size:
%                               a matrix, [Npoints x Nbases].
%       Pby, the derivative to y of the bases, size:
%                               a matrix, [Npoints x Nbases].
%              
%
%   YcZhang 4/8/2017
%   
%   Last modified 4/8/2017
%

useLocalBasis = 1;
if ~useLocalBasis
    xT = 0;
    yT = 0;
    hT = 1;
end

[r, c] = size(x);
if r < c % we need to guarantee the input x is a column vector.
    x = x'; 
end
[r, c] = size(y);
if r < c % we need to guarantee the input y is a column vector.
    y = y';
end

vone = ones(length(x),1);
if k == 0
    Pb = 1*vone;
    Pbx = 0*vone;
    Pby = 0*vone;
elseif k == 1
    Pb = [1*vone, -(xT - x)/hT, -(yT - y)/hT];
    Pbx = [0*vone, 1/hT*vone, 0*vone];
    Pby = [0*vone, 0*vone, 1/hT*vone];
elseif k == 2
    Pb = [1*vone, -(xT - x)/hT, -(yT - y)/hT, (xT - x).^2/hT.^2, ((xT - x).*(yT - y))/hT.^2, (yT - y).^2/hT.^2];
    Pbx = [0*vone, 1/hT*vone, 0*vone, -(2.*xT - 2.*x)/hT.^2, -(yT - y)/hT.^2, 0*vone];
    Pby = [0*vone, 0*vone, 1/hT*vone, 0*vone, -(xT - x)/hT.^2, -(2.*yT - 2.*y)/hT.^2];
elseif k == 3
    Pb = [ 1.*vone, -(xT - x)/hT, -(yT - y)/hT, (xT - x).^2/hT.^2, ((xT - x).*(yT - y))/hT.^2, (yT - y).^2/hT.^2, -(xT - x).^3/hT.^3, -((xT - x).^2.*(yT - y))/hT.^3, -((xT - x).*(yT - y).^2)/hT.^3, -(yT - y).^3/hT.^3];
    Pbx = [ 0.*vone, 1.*vone/hT, 0.*vone, -(2.*xT - 2.*x)/hT.^2, -(yT - y)/hT.^2, 0.*vone, (3.*(xT - x).^2)/hT.^3, ((2.*xT - 2.*x).*(yT - y))/hT.^3, (yT - y).^2/hT.^3, 0.*vone];
    Pby = [ 0.*vone, 0.*vone, 1.*vone/hT, 0.*vone, -(xT - x)/hT.^2, -(2.*yT - 2.*y)/hT.^2, 0.*vone, (xT - x).^2/hT.^3, ((2.*yT - 2.*y).*(xT - x))/hT.^3, (3.*(yT - y).^2)/hT.^3];
elseif k == 4
    Pb = [ 1.*vone, -(xT - x)/hT, -(yT - y)/hT, (xT - x).^2/hT.^2, ((xT - x).*(yT - y))/hT.^2, (yT - y).^2/hT.^2, -(xT - x).^3/hT.^3, -((xT - x).^2.*(yT - y))/hT.^3, -((xT - x).*(yT - y).^2)/hT.^3, -(yT - y).^3/hT.^3, (xT - x).^4/hT.^4, ((xT - x).^3.*(yT - y))/hT.^4, ((xT - x).^2.*(yT - y).^2)/hT.^4, ((xT - x).*(yT - y).^3)/hT.^4, (yT - y).^4/hT.^4];
    Pbx = [ 0.*vone, 1.*vone/hT, 0.*vone, -(2.*xT - 2.*x)/hT.^2, -(yT - y)/hT.^2, 0.*vone, (3.*(xT - x).^2)/hT.^3, ((2.*xT - 2.*x).*(yT - y))/hT.^3, (yT - y).^2/hT.^3, 0.*vone, -(4.*(xT - x).^3)/hT.^4, -(3.*(xT - x).^2.*(yT - y))/hT.^4, -((2.*xT - 2.*x).*(yT - y).^2)/hT.^4, -(yT - y).^3/hT.^4, 0.*vone];
    Pby = [ 0.*vone, 1.*vone/hT, 0.*vone, -(2.*xT - 2.*x)/hT.^2, -(yT - y)/hT.^2, 0.*vone, (3.*(xT - x).^2)/hT.^3, ((2.*xT - 2.*x).*(yT - y))/hT.^3, (yT - y).^2/hT.^3, 0.*vone, -(4.*(xT - x).^3)/hT.^4, -(3.*(xT - x).^2.*(yT - y))/hT.^4, -((2.*xT - 2.*x).*(yT - y).^2)/hT.^4, -(yT - y).^3/hT.^4, 0.*vone];
end








end % function