function [sysErr,sysTime] = dgStokesEqn(pde,option,varargin)
%
%   dgStokesEqn solve the stokes equation by DG methods
%
%
%	YcZhang 15/8/2017
%
%   Last modified 15/8/2017
%

%% Default setting of mesh and pde data
if ~exist('option','var') 
    option = []; 
end
if ~exist('pde','var')
    pde = stokesData(0,7); % default data
end


%% Parameters
option = dgOption(option);
maxIt = option.maxIt;


%% Initialize err
sysErr = zeros(maxIt,1); % not used
sysTime = zeros(maxIt,1); % not used

uh_L2_error = zeros(maxIt,1); uh_H1_error = zeros(maxIt,1);
ph_L2_error = zeros(maxIt,1);
uhL2rate = zeros(maxIt,1); uhH1rate = zeros(maxIt,1);
phL2rate = zeros(maxIt,1);
h = zeros(maxIt,1);


disp('********************  dg Stokes  ********************')
disp('------------------------------------------------------')
disp('poisson Equation:')
disp(['   k_11 = ',func2str( pde.k_11)])
disp(['   k_22 = ',func2str( pde.k_22)])
disp(['   u1 = ',func2str(pde.u1)])
disp(['   u2 = ',func2str(pde.u2)])
disp('DG parameters: ')
disp(['   basesType_u: ', option.basesType_u])
disp(['   basesType_p: ', option.basesType_p])
disp(['   penalty pars: p_epsilon: ', num2str(option.p_epsilon)])
disp(['   penalty pars: p_sigma: ', num2str(option.p_sigma)])
disp(['   penalty pars: p_beta: ', num2str(option.p_beta)])
disp(['   maxIt: ', num2str(maxIt)])

%% DG methods
disp('------------------------------------------------------')
disp('Solving dgStokes: ')
disp('------------------------------------------------------')
format long e
for n = 1:maxIt
    n_str = num2str(n);
    mesh_name = ['Polygon_',n_str];
    load(mesh_name);
    
    disp('')
    n_th_cycle = ['the ',n_str,'-th cycle(i.e. the ', n_str, '-th mesh)'];
    disp(n_th_cycle)
    
    %% get mesh information
    node = vertices;
    elem = elements;
    meshInfo = polyMeshAuxStructure(node, elem);

    %% solve equations
    solve_t0 = cputime;
    [Uh, sysInfo]= dgStokesSolve(meshInfo,pde,option);
    sysInfo.SoverTime = cputime - solve_t0;
    disp(['the solve-func time: ',num2str(sysInfo.SoverTime)])
    
    %% compute the err
    dof_u1 = sysInfo.dof_u1;
    uh1 = Uh(1:dof_u1);
    uh2 = Uh(1+dof_u1:2*dof_u1);
    ph = Uh(1+2*dof_u1:end);
    err_t0 = cputime;
    [uh1_L2_error, uh1_H1_error] = dgL2H1Error(pde.u1,pde.u1x,pde.u1y,uh1,meshInfo,sysInfo.Gaussformulas{1},option.basesType_u);
    [uh2_L2_error, uh2_H1_error] = dgL2H1Error(pde.u2,pde.u2x,pde.u2y,uh2,meshInfo,sysInfo.Gaussformulas{1},option.basesType_u);
    [ph_L2_error(n), ~] = dgL2H1Error(pde.p,pde.px,pde.py,ph,meshInfo,sysInfo.Gaussformulas{1},option.basesType_p);
    uh_L2_error(n) = sqrt(uh1_L2_error^2+uh2_L2_error^2);
    uh_H1_error(n) = sqrt(uh1_H1_error^2+uh2_H1_error^2);
    sysInfo.ErrTime = cputime - err_t0;
    disp(['compute Err time: ',num2str(sysInfo.ErrTime)])
    
    %% other options
    h(n) = 1./(sqrt(meshInfo.Nnodes)-1);

    disp('------------------------------------------------------')
end % for n

disp('------------------------------------------------------')
%%
uh_L2_error
uh_H1_error
ph_L2_error

uhL2rate(2:maxIt) = log(uh_L2_error(1:maxIt-1)./uh_L2_error(2:maxIt)) ...
    ./log(h(1:maxIt-1)./h(2:maxIt))
uhH1rate(2:maxIt) =  log(uh_H1_error(1:maxIt-1)./uh_H1_error(2:maxIt)) ...
    ./log(h(1:maxIt-1)./h(2:maxIt))
phL2rate(2:maxIt) =  log(ph_L2_error(1:maxIt-1)./ph_L2_error(2:maxIt)) ...
    ./log(h(1:maxIt-1)./h(2:maxIt))

end % function dgPoissonEqn
